package com.cts.spring.boot.DatabaseTestTwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseTestTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseTestTwoApplication.class, args);
	}
}
